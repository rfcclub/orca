import { ArtifactType } from '../types.js'

export interface ArtifactContext {
  artifact_type: ArtifactType
  activates: string[]
}

const RULE_ACTIVATIONS: Record<ArtifactType, string[]> = {
  migration:    ['AX503', 'TW201'],
  code_diff:    ['TW201', 'TW203'],
  test_plan:    ['TW202'],
  llm_response: ['TW201'],
  design:       [],
  plan_review:  ['PR001', 'PR002', 'PR003', 'PR004'],
}

export class ArtifactClassifier {
  static classify(artifact_type: ArtifactType): ArtifactContext {
    return { artifact_type, activates: RULE_ACTIVATIONS[artifact_type] ?? [] }
  }
}
